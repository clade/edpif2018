rubidium_87 = 86.9091805527
rubidium_85 = 85
